# Daniels

Inside, you'll find Daniel. Daniel is harvested's open source contribution. He's the slack bot we use for all of our monitoring -- you can essentially import him and have him talk to various channels in slack, alerting people he needs to talk with.

A few potential use cases include pipeline monitoring, event alerts, and production error notifications. For small teams who don't have time to watch everything at once but also can't just wait until they notice things have broken, Daniel can be invaluable.  
